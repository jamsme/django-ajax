from django.apps import AppConfig


class AjaxSearchConfig(AppConfig):
    name = 'ajax_search'
