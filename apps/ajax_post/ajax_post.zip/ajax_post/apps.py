from django.apps import AppConfig


class AjaxPostConfig(AppConfig):
    name = 'ajax_post'
