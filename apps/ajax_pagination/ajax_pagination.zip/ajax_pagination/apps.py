from django.apps import AppConfig


class AjaxPaginationConfig(AppConfig):
    name = 'ajax_pagination'
