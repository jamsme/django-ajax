from django.apps import AppConfig


class AjaxDemoConfig(AppConfig):
    name = 'ajax_demo'
